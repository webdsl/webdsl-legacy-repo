package org.w3c.dom;

public interface NodeList {
  
  public Node item(int index);
  public int  getLength();

}
