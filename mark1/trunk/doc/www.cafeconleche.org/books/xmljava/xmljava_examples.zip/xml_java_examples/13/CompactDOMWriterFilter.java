package org.w3c.dom.ls;

public interface DOMWriterFilter extends NodeFilter {

  public int getWhatToShow();

}