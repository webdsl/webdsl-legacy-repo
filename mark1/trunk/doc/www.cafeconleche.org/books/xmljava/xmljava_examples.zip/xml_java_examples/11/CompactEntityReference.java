package org.w3c.dom;

public interface EntityReference extends Node {

}
