package org.w3c.dom;

public interface CDATASection extends Text {

}
