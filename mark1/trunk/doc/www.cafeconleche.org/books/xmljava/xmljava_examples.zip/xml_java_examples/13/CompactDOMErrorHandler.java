package org.w3c.dom;

public interface DOMErrorHandler {

  public boolean handleError(DOMError error);

}
