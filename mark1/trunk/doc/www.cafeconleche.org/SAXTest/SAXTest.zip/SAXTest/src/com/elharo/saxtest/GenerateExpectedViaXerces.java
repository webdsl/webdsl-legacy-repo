package com.elharo.saxtest;

import java.io.*;
import java.net.URI;
import java.net.URISyntaxException;

import nu.xom.*;

import org.xml.sax.*;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;

/* This class makes the expected files based solely on Xerces */
public class GenerateExpectedViaXerces {
    

    public static void main(String[] args) {
        
        try {
            runXMLConformanceTestSuite();
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        
    }

    
    public static void generate(String uri) throws IOException, SAXException {
        
        // Xerces screws up if we reuse the parser
        System.setProperty("org.apache.xerces.xni.parser.XMLParserConfiguration", 
          "org.apache.xerces.parsers.XML11Configuration");
        XMLReader parser = XMLReaderFactory.createXMLReader("org.apache.xerces.parsers.SAXParser");
        InputSource original = new InputSource(uri); 
        ConformanceReportHandler handler = new ConformanceReportHandler();
        parser.setContentHandler(handler);
        parser.setDTDHandler(handler);
        parser.setErrorHandler(handler);
        parser.setEntityResolver(handler);
        parser.setFeature(
          "http://xml.org/sax/features/external-general-entities",
          true
        );
        parser.setFeature(
         "http://xml.org/sax/features/external-parameter-entities",
          true
        ); 
        
        try {
            parser.parse(original);
        }
        catch (SAXException ex) {
            // no big deal; fatalError should have been called
        }
        catch (UTFDataFormatException ex) {
            // Xerces reports some character encoding errors as IOExceptions
            // rather than SAXParseExceptions
            addFatalError(handler.getResult());
        }
        catch (CharConversionException ex) {
            System.err.println(uri);
            addFatalError(handler.getResult());
        }
        catch (IOException ex) {
            ex.printStackTrace();
            throw ex;
        }
        
        Document result = handler.getResult();
        // fix known bugs in Xerces
        addStartDocument(result);
        addEndDocument(result);
        removePostRootCharacters(result);
        // addFatalError(result);
        
        File output = new File("results");
        output = new File(output, "preexpected");
        int position = uri.lastIndexOf("xmlconf/") + "xmlconf/".length();
        String localPart = uri.substring(position);
        
        output = new File(output, localPart);
        File parent = output.getParentFile();
        if (! parent.exists()) parent.mkdirs();
        OutputStream out = new BufferedOutputStream(new FileOutputStream(output));
        Serializer serializer = new Serializer(out);
        serializer.setLineSeparator("\n");
        serializer.setIndent(4);
        serializer.write(result);
        
        serializer.flush();
        out.close();
        
    }
    

    private static void addEndDocument(Document doc) {
        Element root = doc.getRootElement();
        Elements ends = root.getChildElements("endDocument");
        if (ends.size() == 0) {
            root.appendChild(new Element("endDocument"));
        }
    }


    private static void addFatalError(Document doc) {
        
        Element root = doc.getRootElement();
        Elements children = root.getChildElements();
        Element last = children.get(children.size()-1);
        if (last.getQualifiedName().equals("endDocument")) {
            root.insertChild(new Element("fatalError"), root.getChildCount()-1);
        }
        else {
            root.appendChild(new Element("fatalError"));
        }
        
    }


    private static void addStartDocument(Document doc) {
        Element root = doc.getRootElement();
        Elements starts = root.getChildElements("startDocument");
        if (starts.size() == 0) {
            root.insertChild(new Element("startDocument"), 0);
        }
    }


    private static void removePostRootCharacters(Document doc) {
        Element root = doc.getRootElement();
        Elements ends = root.getChildElements("endElement");
        Elements errors = root.getChildElements("fatalError"); 
        if (ends.size() > 0 && errors.size() == 0) {
            int index = root.indexOf(ends.get(ends.size()-1));
            for (int i = root.getChildCount()-1; i > index; i--) {
                Element post = (Element) root.getChild(i);
                if (post.getLocalName().equals("char")) post.detach();
            }
        }
    }


    public static void runXMLConformanceTestSuite() 
      throws URISyntaxException, ParsingException, IOException, SAXException {
      
        Builder builder = new Builder(new XMLBaseFilter());
        File masterList = new File("xmlconf/xmlconf.xml");
        
        if (masterList.exists()) {
            Document xmlconf = builder.build(masterList);
            Elements testcases = xmlconf.getRootElement().getChildElements("TESTCASES");
            processTestCases(testcases);
        }
        else {
            System.err.println("Could not load conformance suite");
        }

    }

    
    private static void processTestCases(Elements testcases) 
      throws URISyntaxException, ParsingException, IOException, SAXException {
        
        for (int i = 0; i < testcases.size(); i++) {
              Element testcase = testcases.get(i); 
              Elements tests = testcase.getChildElements("TEST");
              processTests(tests);
              Elements level2 = testcase.getChildElements("TESTCASES");
              // need to be recursive to handle recursive IBM test cases
              processTestCases(level2);
        }
        
    }

    
    private static Builder builder = new Builder();

    private static void processTests(Elements tests) 
      throws URISyntaxException, ParsingException, IOException, SAXException  {

        for (int i = 0; i < tests.size(); i++) {
            Element test = tests.get(i);
            String uri = test.getAttributeValue("URI");
            String base = test.getBaseURI();
            URI baseURI= new URI(base);
            URI testURI = baseURI.resolve(uri);
            generate(testURI.toString());
        }
        
    }
    
    
    // The test suite uses incorrect xml:base attributes that need to be removed
    private static class XMLBaseFilter extends NodeFactory {
        
        private Nodes empty = new Nodes();
        
        public Nodes makeAttribute(String name, String URI, String value, Attribute.Type type) {
            if ("xml:base".equals(name)) return empty;
            else return super.makeAttribute(name, URI, value, type);
        }
        
    }
    
    
}
