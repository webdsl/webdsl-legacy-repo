package com.elharo.saxtest;

import java.io.*;
import java.net.URI;
import java.net.URISyntaxException;

import nu.xom.*;

import org.xml.sax.*;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;

public class ConformanceGenerator {
    
    // XXX push this out into a config file
    static String[] parsers = {
        "org.apache.xerces.parsers.SAXParser" , // http://xml.apache.org/xerces2-j/
        "gnu.xml.aelfred2.XmlReader",          // http://www.gnu.org/software/classpathx/jaxp/
        "org.apache.crimson.parser.XMLReaderImpl",  // bundled with JDK 1.4
        "com.bluecast.xml.Piccolo",            // http://piccolo.sourceforge.net/ 
        "oracle.xml.parser.v2.SAXParser",      // http://otn.oracle.com/tech/xml/xdk/software/prod/xdk_java.html
        "com.jclark.xml.sax.SAX2Driver",       // http://www.xmlmind.com/xpforjaxp.html 
        "net.sf.saxon.aelfred.SAXDriver",      // http://saxon.sourceforge.net/aelfred.html
        "org.dom4j.io.aelfred.SAXDriver"       // http://www.dom4j.org/download.html 
    };
    
    
    public static void main(String[] args) {
        
        if (args.length == 0) {
            args = parsers;
        }

        XMLReader parser;
        System.setProperty("org.apache.xerces.xni.parser.XMLParserConfiguration", 
          "org.apache.xerces.parsers.XML11Configuration");
        for (int i = 0; i < args.length; i++) {
            try {
                parser = XMLReaderFactory.createXMLReader(args[i]);
            }
            catch (SAXException ex) {
                // specified parser is not in the classpath
                System.err.println(ex);
                continue;
            }
        
            try {
                System.err.println("Testing " + parser.getClass().getName());
                runXMLConformanceTestSuite(parser);
            }
            catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        
    }

    
    public static void generate(String uri, XMLReader parser) 
      throws IOException {
        
        InputSource original = new InputSource(uri); 
        ConformanceReportHandler handler = new ConformanceReportHandler();
        parser.setContentHandler(handler);
        parser.setDTDHandler(handler);
        parser.setErrorHandler(handler);
        parser.setEntityResolver(handler);
        try {
            parser.setFeature(
              "http://xml.org/sax/features/external-general-entities",
              true
            );
            parser.setFeature(
             "http://xml.org/sax/features/external-parameter-entities",
              true
            );        }
        catch (SAXException ex) {
            // don't yet test parser without these features
            return;
        }
        
        try {
            parser.parse(original);
        }
        catch (SAXException ex) {
            // a non-wellformed test case, but the output should be well-formed 
            // could add an extra element here to indicate
            // specific exception thrown????
        }
        catch (IOException ex) {
            // a non-wellformed test case, probably bad character data,
            // but the output should be well-formed 
            // should add an IOException element to list????
        }
        catch (XMLException ex) {
            // ex.printStackTrace();
            System.err.println(ex);
            throw ex;
        }
        catch (Exception ex) {
            ex.printStackTrace();
            Element root = handler.getResult().getRootElement();
            Element bug = new Element("bug");
            bug.addAttribute(new Attribute("reason", "Parser should only throw SAXExceptions"));
            bug.addAttribute(new Attribute("type", ex.getClass().getName()));
            bug.appendChild(ex.getMessage());
            root.appendChild(bug);
        }
        
        Document result = handler.getResult();
        File output = new File("results");
        output = new File(output, parser.getClass().getName());
        int position = uri.lastIndexOf("xmlconf/") + "xmlconf/".length();
        String localPart = uri.substring(position);
        
        output = new File(output, localPart);
        File parent = output.getParentFile();
        if (! parent.exists()) parent.mkdirs();
        OutputStream out = new BufferedOutputStream(new FileOutputStream(output));
        Serializer serializer = new Serializer(out);
        serializer.setLineSeparator("\n");
        serializer.setIndent(4);
        serializer.write(result);
        
        serializer.flush();
        out.close();
        
    }
    

    public static void runXMLConformanceTestSuite(XMLReader parser) 
      throws URISyntaxException, ParsingException, IOException, SAXException {
      
        Builder builder = new Builder(new XMLBaseFilter());
        File masterList = new File("xmlconf/xmlconf.xml");
        File output = new File(parser.getClass().getName());
        
        if (masterList.exists()) {
            Document xmlconf = builder.build(masterList);
            Elements testcases = xmlconf.getRootElement().getChildElements("TESTCASES");
            processTestCases(testcases, parser);
        }
        else {
            System.err.println("Could not load conformance suite");
        }

    }

    
    private static void processTestCases(Elements testcases, XMLReader parser) 
      throws URISyntaxException, ParsingException, IOException, SAXException {
        
        for (int i = 0; i < testcases.size(); i++) {
              Element testcase = testcases.get(i); 
              Elements tests = testcase.getChildElements("TEST");
              processTests(tests, parser);
              Elements level2 = testcase.getChildElements("TESTCASES");
              // need to be recursive to handle recursive IBM test cases
              processTestCases(level2, parser);
        }
        
    }

    
    private static Builder builder = new Builder();

    private static void processTests(Elements tests, XMLReader parser) 
      throws URISyntaxException, ParsingException, IOException, SAXException  {

        for (int i = 0; i < tests.size(); i++) {
            Element test = tests.get(i);
            String uri = test.getAttributeValue("URI");
            String base = test.getBaseURI();
            URI baseURI= new URI(base);
            URI testURI = baseURI.resolve(uri);
            generate(testURI.toString(), parser);
        }
        
    }
    
    
    // The test suite uses incorrect xml:base attributes that need to be removed
    private static class XMLBaseFilter extends NodeFactory {
        
        private Nodes empty = new Nodes();
        
        public Nodes makeAttribute(String name, String URI, String value, Attribute.Type type) {
            if ("xml:base".equals(name)) return empty;
            else return super.makeAttribute(name, URI, value, type);
        }
        
    }
    
    
}
