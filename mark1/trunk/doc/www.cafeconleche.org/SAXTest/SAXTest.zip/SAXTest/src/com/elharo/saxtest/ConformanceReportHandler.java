package com.elharo.saxtest;


import java.util.Iterator;
import java.util.SortedMap;
import java.util.TreeMap;

import nu.xom.Attribute;
import nu.xom.Document;
import nu.xom.Element;
import nu.xom.MultipleParentException;

import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.DTDHandler;
import org.xml.sax.EntityResolver;
import org.xml.sax.ErrorHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXParseException;


/**
 * @author Elliotte Rusty Harold
 *
 */
public class ConformanceReportHandler
  implements ContentHandler, ErrorHandler, DTDHandler, EntityResolver {

    private Element root = new Element("ConformanceResults");
    private Document result = new Document(root); 
    private boolean inProlog = true;
    
       
    // can't rely on endDocument or startDocument being called because 
    // some parsers get this wrong.
    // Instead the invoker has to call getResult.
    public Document getResult() {
        return result;
    }

    // ContentHandler Methods
    public void startDocument() {
        Element element = new Element("startDocument");
        root.appendChild(element);
    }
    
    
    public void endDocument() { 
        
        flushEndPrefixMappings();
        Element element = new Element("endDocument");
        root.appendChild(element);
        // should endDocument always be called, even after a fatal error?
        // docs appear to say this; neither Crimson nor Xerces seems to do this
        // but yes; it should
    }


    public void characters(char[] text, int start, int length) {
        
        flushEndPrefixMappings();
        for (int i = start; i < start+length; i++) {
            Element c = new Element("char");
            root.appendChild(c);
            c.appendChild(escape(text[i]));
        }
        
    }

    
    private static String escape(char c) {
        
        StringBuffer sb = new StringBuffer();
        switch (c) {
            case ' ':
                sb.append("\\s");
                break;
            case '\n':
                sb.append("\\n");
                break;
            case '\r':
                sb.append("\\r");
                break;
            case '\t':
                sb.append("\\t");
                break;
            case '\\':
                sb.append("\\\\");
                break;
            case 0xFFFE:
                sb.append("\\uFFFE");
                break;
            case 0xFFFF:
                sb.append("\\uFFFF");
                break;
            default:
                if (c < ' ') {
                    sb.append("\\u" + Integer.toHexString(c).toUpperCase());
                }
                else if (c >= 127 && c <= 160 || c >= 0xD800 && c < 0xE000) {
                    // surrogate or private use character
                    // not legal in XML but they are tested for
                    sb.append("\\u" + Integer.toHexString(c).toUpperCase());                        
                }
                else sb.append(c);
        }
        return sb.toString();
        
    }

    private static String escape(String text) {
        return escape(text.toCharArray(), 0, text.length());
    }

    
    private static String escape(char[] text, int start, int length) {
        
        StringBuffer sb = new StringBuffer(length);
        for (int i = start; i < start+length; i++) {
            sb.append(escape(text[i]));
        }
        return sb.toString();
        
    }

    public void ignorableWhitespace(char[] text, int start, int length) {
        
        flushEndPrefixMappings();
        for (int i = start; i < start+length; i++) {
            Element c = new Element("ignorable");
            root.appendChild(c);
            c.appendChild(escape(text[i]));
        }
        
    }


    // startPrefixMapping and endPrefixMapping order is not guaranteed
    private SortedMap startPrefixMappings;
    private SortedMap endPrefixMappings;
    
    
    public void startPrefixMapping(String prefix, String uri) {
        
        flushEndPrefixMappings();     
        Element element = new Element("startPrefixMapping");
        Element prefixChild = new Element("prefix");
        Element uriChild = new Element("data");
        prefixChild.appendChild(prefix);
        uriChild.appendChild(uri);
        element.appendChild(prefixChild);
        element.appendChild(uriChild);
        
        if (startPrefixMappings == null) startPrefixMappings = new TreeMap();
        String key = prefix + "\u0000" + uri;
        startPrefixMappings.put(key, element);
        
    }


    public void endPrefixMapping(String prefix) {
        
        Element element = new Element("endPrefixMapping");
        Element prefixChild = new Element("prefix");
        prefixChild.appendChild(prefix);
        element.appendChild(prefixChild);
        
        if (endPrefixMappings == null) endPrefixMappings = new TreeMap();
        endPrefixMappings.put(prefix, element);
        
    }
    
    
    public void skippedEntity(String name) {
        
        flushEndPrefixMappings();
        Element element = new Element("skippedEntity");
        Element child = new Element("name");
        child.appendChild(name);
        element.appendChild(child);
        root.appendChild(element);
        
    }


    private Locator locator;
    private String uri;
    
    public void setDocumentLocator(Locator locator) {
        
        // this is optional; mostly for debugging;
        // However, if it is called it must be the first thing called;
        // even before startDocument
        this.locator = locator;
        this.uri = locator.getSystemId();
        // I only note this if it's in the wrong place, so that the 
        // comparison will fail. 
        if (root.getChildCount() > 0) {
            root.appendChild(new Element("locator"));
        }
        
    }


    public void processingInstruction(String target, String value) {
        
        flushEndPrefixMappings();
        Element element = new Element("processingInstruction");
        Element targetChild = new Element("target");
        Element dataChild = new Element("data");
        targetChild.appendChild(target);
        dataChild.appendChild(escape(value));
        element.appendChild(targetChild);
        element.appendChild(dataChild);
        
        root.appendChild(element);
        
    }


    public void startElement(String namespaceURI, String localName,
      String qualifiedName, Attributes attributes) {
        
        if (inProlog) {
            flushProlog();
            inProlog = false;
        }
        
        flushEndPrefixMappings();
        if (startPrefixMappings != null) {
           Iterator iterator = startPrefixMappings.values().iterator();
           while (iterator.hasNext()) {
               root.appendChild((Element) iterator.next());
           }
           startPrefixMappings = null;
        }
        
        Element element = new Element("startElement");
        if (namespaceURI != null) {
            Element uriChild = new Element("namespaceURI");
            uriChild.appendChild(namespaceURI);
            element.appendChild(uriChild);
        }
        
        if (localName != null) {
            Element localChild = new Element("localName");
            localChild.appendChild(localName);
            element.appendChild(localChild);
        }
        
        if (qualifiedName != null) {
            Element qnameChild = new Element("qualifiedName");
            qnameChild.appendChild(qualifiedName);
            element.appendChild(qnameChild);
        }
        
        Element attributesChild = new Element("attributes");
        // The order to sort the attributes in doesn't matter
        // as long as it's reproducible
        SortedMap map = new TreeMap();
        for (int i = 0; i < attributes.getLength(); i++) {
           String lName = attributes.getLocalName(i);
           String qName = attributes.getQName(i);
           String uri = attributes.getURI(i);
           String key = "";
           if (lName != null) key+= lName;
           key += '\u0000';
           if (qName != null) key+= qName;
           key += '\u0000';
           if (uri != null) key+= uri;
           map.put(key, new Integer(i));
        }
        
        Iterator iterator = map.values().iterator();
        while (iterator.hasNext()) {
            int index = ((Integer) iterator.next()).intValue();
            String lName = attributes.getLocalName(index);
            String qName = attributes.getQName(index);
            String uri = attributes.getURI(index);
            String value = attributes.getValue(index);
            String type = attributes.getType(index);
            
            Element attribute = new Element("attribute");
            
            if (uri != null) {
                Element namespaceChild = new Element("namespaceURI");
                namespaceChild.appendChild(uri);
                attribute.appendChild(namespaceChild);
            }
            
            if (lName != null) {
                Element lNameChild = new Element("localName");
                lNameChild.appendChild(lName);
                attribute.appendChild(lNameChild);
            }
            
            if (qName != null) {
                Element qNameChild = new Element("qualifiedName");
                qNameChild.appendChild(qName);
                attribute.appendChild(qNameChild);
            }
            
            Element valueChild = new Element("value");
            valueChild.appendChild(escape(value));
            attribute.appendChild(valueChild);
            
            Element typeChild = new Element("type");
            typeChild.appendChild(escape(type));
            attribute.appendChild(typeChild);
            
            attributesChild.appendChild(attribute);
        }

        element.appendChild(attributesChild);
        
        root.appendChild(element);

    }

    
    public void endElement(
      String namespaceURI, String localName, String qualifiedName) {
        
        flushEndPrefixMappings();
        
        Element element = new Element("endElement");
        
        if (namespaceURI != null) {
            Element uriChild = new Element("namespaceURI");
            uriChild.appendChild(namespaceURI);
            element.appendChild(uriChild);
        }
        
        if (localName != null) {
            Element localChild = new Element("localName");
            localChild.appendChild(localName);
            element.appendChild(localChild);
        }
        
        if (qualifiedName != null) {
            Element qnameChild = new Element("qualifiedName");
            qnameChild.appendChild(qualifiedName);
            element.appendChild(qnameChild);
        }
        
        root.appendChild(element);
        
    }

    
    private void flushEndPrefixMappings() {
        
        if (endPrefixMappings != null) {
           Iterator iterator = endPrefixMappings.values().iterator();
           while (iterator.hasNext()) {
               root.appendChild((Element) iterator.next());
           }
           endPrefixMappings = null;
        }             
    }
    
    
    // ErrorHandler methods
    public void error(SAXParseException ex) {
        // reporting errors is optional
    }


    public void fatalError(SAXParseException ex) {
        flushEndPrefixMappings();
        root.appendChild(new Element("fatalError"));
    }


    public void warning(SAXParseException ex) {
        // warnings are optional
    }

    
    private SortedMap notations = new TreeMap();
    private SortedMap entities = new TreeMap();
    
    // DTDHandler methods
    public void notationDecl(String name, String publicID, String systemID) {

        Element notation = new Element("notation");
        
        if (name != null) {
            Element nameElement = new Element("name");
            notation.appendChild(nameElement);
            nameElement.appendChild(escape(name));
        }
        if (publicID != null) {
            Element publicElement = new Element("publicID");
            publicElement.appendChild(escape(publicID));
            notation.appendChild(publicElement);
        }
        if (systemID != null) {
            Element systemElement = new Element("systemID");
            systemElement.appendChild(escape(systemID));
            notation.appendChild(systemElement);
        }
        
        // is there a problem if two notations have same name????
        if (inProlog) notations.put(name, notation);
        else {
            Element bug = new Element("bug");
            bug.addAttribute(new Attribute("reason", 
              "notation reported after first startElement"));
            bug.appendChild(notation);
            root.appendChild(bug);
        }
        
    }


    public void unparsedEntityDecl(
      String name, String publicID, String systemID, String notation) {
        
        Element unparsedEntity = new Element("unparsedEntity");
        
        if (name != null) {
            Element nameElement = new Element("name");
            unparsedEntity.appendChild(nameElement);
            nameElement.appendChild(name);
        }
        if (publicID != null) {
            Element publicElement = new Element("publicID");
            publicElement.appendChild(publicID);
            unparsedEntity.appendChild(publicElement);
        }
        if (systemID != null) {
            Element systemElement = new Element("systemID");
            systemElement.appendChild(systemID);
            unparsedEntity.appendChild(systemElement);
        }
        if (notation != null) {
            Element notationElement = new Element("notation");
            notationElement.appendChild(notation);
            unparsedEntity.appendChild(notationElement);
        }
        
        // problem if two entities have same name????
        // and for attributes????
        if (inProlog) entities.put(name, unparsedEntity);
        else {
            Element bug = new Element("bug");
            bug.addAttribute(new Attribute("reason", "unparsed entity reported after first startElement"));
            bug.appendChild(unparsedEntity);
            root.appendChild(bug);
        }

    }


    public InputSource resolveEntity(String publicID, String systemID) {
        
        // this.flushProlog(); ????
        flushEndPrefixMappings();
        Element entity = new Element("resolveEntity");
        if (publicID != null) {
            Element publicElement = new Element("publicID");
            publicElement.appendChild(escape(publicID));
            entity.appendChild(publicElement);
        }
        if (systemID != null) {
            Element systemElement = new Element("systemID");
            systemElement.appendChild(escape(systemID));
            entity.appendChild(systemElement);
        }
        root.appendChild(entity);
        return null;
        
    }

    
    private void flushProlog() {
        
       Iterator iterator = notations.values().iterator();
       while (iterator.hasNext()) {
           root.appendChild((Element) iterator.next());
       }  
       
       Iterator unparsed = entities.values().iterator();
       
       while (unparsed.hasNext()) {
           Element next;
           try {
               next = (Element) unparsed.next();
               root.appendChild(next);
           }
           catch (MultipleParentException ex) {
               throw ex;   
           }
       }  
       
    }

    
}
