package com.elharo.saxtest;

import java.io.*;

import org.xml.sax.*;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;

public class BugTest {
    
    public static void main(String[] args) {

        try {
            XMLReader parser = XMLReaderFactory.createXMLReader("org.apache.xerces.parsers.SAXParser");

            System.err.println("Testing " + parser.getClass().getName());
            generate(parser);
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        
        System.err.flush();
        
    }

    
    public static void generate(XMLReader parser) 
      throws Exception {
        TestHandler handler = new TestHandler();
        parser.setContentHandler(handler);
        parser.setErrorHandler(handler);
        
        try {
            parser.parse("file:/home/elharo/SAXTest/xmlconf/xmltest/valid/sa/001.xml");
        }
        catch (SAXException ex) {
            
        }
        try {
            parser.parse("file:/home/elharo/SAXTest/xmlconf/xmltest/not-wf/sa/025.xml");
        }
        catch (SAXException ex) {
            
        }

        
        
        String base = "xmlconf/xmltest/not-wf/sa/0";
        for (int i = 27; i <= 27; i++) {
            File input = new File(base + i + ".xml");
            InputSource original = new InputSource(new FileInputStream(input));
            original.setSystemId(input.toURI().toString());
            
            try {
                parser.parse(original);
            }
            catch (Exception ex) {
                System.err.println(ex);
            }
        }

        
    }    

    
    
}

class TestHandler
  implements ContentHandler, ErrorHandler {

    // ContentHandler Methods
    public void startDocument() {
    }
    
    
    public void endDocument() { 

    }




    public void characters(char[] text, int start, int length) {
        
        if (this.uri.indexOf("not-wf/sa/027.xml") != -1) {
            System.err.println(new String(text, start, length));
        }
        
    }

   
    public void ignorableWhitespace(char[] text, int start, int length) {
        
    }


    public void startPrefixMapping(String prefix, String uri) {
        
    }


    public void endPrefixMapping(String prefix) {

        
    }
    
    
    public void skippedEntity(String name) {
        
    }


    private Locator locator;
    private String uri;
    
    public void setDocumentLocator(Locator locator) {
        // this is optional; mostly for debugging
        this.locator = locator;
        this.uri = locator.getSystemId();
    }


    public void processingInstruction(String target, String value) {
        
    }


    public void startElement(String namespaceURI, String localName,
      String qualifiedName, Attributes attributes) {

    }

    
    public void endElement(String namespaceURI, String localName, String qualifiedName) {
        
    }

    
    private void flushEndPrefixMappings() {
                
    }
    
    // ErrorHandler methods
    public void error(SAXParseException ex) {
    }


    public void fatalError(SAXParseException ex) {
    }


    public void warning(SAXParseException ex) {
        // warnings are optional
    }



}
