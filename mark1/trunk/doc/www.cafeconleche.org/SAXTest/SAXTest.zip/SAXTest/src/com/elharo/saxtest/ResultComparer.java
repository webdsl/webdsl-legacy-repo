package com.elharo.saxtest;

import java.io.*;
import java.net.URI;
import java.net.URISyntaxException;

import junit.framework.AssertionFailedError;

import nu.xom.*;
import nu.xom.tests.XOMTestCase;
import nu.xom.xinclude.XIncluder;

// use getPath on URI rather than string manipulation????

public class ResultComparer {
    
    private int testsRun = 0;
    private int testsPassed = 0;
    private String parser;

    public ResultComparer(String parser) {
        this.parser = parser;
    }
    
    public static void main(String[] args) 
      throws URISyntaxException, ParsingException, IOException {
        
        if (args.length == 0) {
            args = ConformanceGenerator.parsers;
        }
        
        for (int i = 0; i < args.length; i++) {
            
            String parser = args[i];
            ResultComparer comparer = new ResultComparer(parser);
            System.out.println("Comparing " + parser);
            Document result = comparer.compareResults();
            
            OutputStream out = new BufferedOutputStream(new FileOutputStream(parser + ".xml"));
            try {
                Serializer serializer = new Serializer(out);
                serializer.setIndent(4);
                serializer.setLineSeparator("\n");
                serializer.write(result);
                serializer.flush();
            }
            finally {
                out.close();
            }
            System.out.println();
            
        }
        
    }

    
    private Builder builder = new Builder();
    
    private boolean compare(String expectedURI, String actualURI) 
      throws ParsingException, IOException {
        
        testsRun++;
        // System.err.println(actualURI + ": " + testsRun);
        Document expectedDoc = builder.build(expectedURI);
        Document actualDoc = builder.build(actualURI);
        
        /*Elements actualEvents = actualDoc.getRootElement().getChildElements();
        Elements expectedEvents = expectedDoc.getRootElement().getChildElements(); 
        
        int min = actualEvents.size() < expectedEvents.size() ? actualEvents.size() : expectedEvents.size();
        for (int i = 0; i < min; i++) {
            Element expected = expectedEvents.get(i);
            Element actual = actualEvents.get(i);
            // need to replace with custom compare code????
            // this code could identify certain common problems,
            // and then add them to the output so I wouldn't need to
            // manually inspect each result, if I know
            // there's a missing endDocument or an ENUMERATION type
            // attribute
            // could also take account of non-difference between file:///
            // and file:/ in systemID elements, or even ignore initial
            // part of absilute system IDs that point to local file system
            try {
                XOMTestCase.assertEquals(expectedEvents.get(i), actualEvents.get(i));
            }
            catch (AssertionFailedError error) {
                if (expected.getQualifiedName().equals("fatalError")) {
                    // Be careful because several parsers don't call endDocument where they should
                    try {
                        if (actualEvents.get(actualEvents.size() - 2).getQualifiedName().equals("fatalError")
                           && actualEvents.get(actualEvents.size() - 1).getQualifiedName().equals("endDocument")) {
                            if (expectedEvents.get(expectedEvents.size() - 1).getQualifiedName().equals("endDocument")) {
                                testsPassed++;
                                return true;
                            }
                            else {
                                return false;
                            }
                        }
                        else {
                            return false;
                        }
                    }
                    catch (ArrayIndexOutOfBoundsException ex) {
                        return false;
                    }
                }
                else if (actual.getQualifiedName().equals("fatalError")) {
                    try {
                        if (expectedEvents.get(expectedEvents.size() - 2).getQualifiedName().equals("fatalError")) {
                            if (actualEvents.get(actualEvents.size() - 1).getQualifiedName().equals("endDocument")) {
                                testsPassed++;
                                return true;
                            }
                            else {
                                return false;
                            }
                        }
                        else {
                            return false;
                        }
                    }
                    catch (ArrayIndexOutOfBoundsException ex) {
                        return false;
                    }
                }
                else if ((actual.getQualifiedName().equals("characters") || actual.getQualifiedName().equals("ignorableWhitespace"))
                  && (expected.getQualifiedName().equals("characters") || expected.getQualifiedName().equals("ignorableWhitespace"))
                  && (expected.getValue().startsWith(actual.getValue()) 
                      || actual.getValue().startsWith(expected.getValue()))) {
                    if (expectedEvents.get(expectedEvents.size() - 2).getQualifiedName().equals("fatalError")
                      && actualEvents.get(actualEvents.size() - 2).getQualifiedName().equals("fatalError")
                      && actualEvents.get(actualEvents.size() - 1).getQualifiedName().equals("endDocument")) {
                        testsPassed++;
                        return true;
                    }
                    else {
                       return false; 
                    }
                }
                else {
                    System.out.println("Discrepancy when comparing " + actualURI);
                    return false;
                }
            }
        }
        
        // If we get this far, then there are no fatal errors
        if (actualEvents.size() != expectedEvents.size()) return false; 
        
        testsPassed++;
        return true;*/
        
        if (compare(expectedDoc, actualDoc)) {
            testsPassed++;
            return true;
        }
        return false;
        
    }
    
    
    private boolean compare(Document expectedDoc, Document actualDoc) {
     
        Element actualRoot = actualDoc.getRootElement();
        Element expectedRoot = expectedDoc.getRootElement();
        Elements expectedChildren = expectedRoot.getChildElements();
        Elements actualChildren = actualRoot.getChildElements();
        int actualSize = actualChildren.size();
        int expectedSize = expectedChildren.size();

        if (actualSize == 0) return false;

        if (!"startDocument".equals(actualChildren.get(0).getQualifiedName())) {
            return false;
        }
        // uncomment if block to require doucments to end with endDocument
        /* if (!"endDocument".equals(actualChildren.get(actualSize-1).getQualifiedName())) {
            return false;
        } */
        
        
        // compare notations
        Elements actualNotations = actualRoot.getChildElements("notation");
        Elements expectedNotations = expectedRoot.getChildElements("notation");
        if (actualNotations.size() != expectedNotations.size()) {
            return isDoubleFatality(expectedChildren, actualChildren);
        }
        for (int i = 0; i < actualNotations.size(); i++) {
            if (!containsNotation(expectedNotations, actualNotations.get(i))) {
                return isDoubleFatality(expectedChildren, actualChildren);
            }
        }
        
        // compare unparsed entities
        Elements actualEntities = actualRoot.getChildElements("unparsedEntity");
        Elements expectedEntities = expectedRoot.getChildElements("unparsedEntity");
        if (actualEntities.size() != expectedEntities.size()) {
            return isDoubleFatality(expectedChildren, actualChildren);
        }
        for (int i = 0; i < actualEntities.size(); i++) {
            if (!containsEntity(expectedEntities, actualEntities.get(i))) {
                return false;
            }
        }
        
        
        int expected = 1; // 0 is startDocument
        while (true) {
            Element e = expectedChildren.get(expected);
            String eName = e.getLocalName();
            if (eName.equals("notation") || eName.equals("unparsedEntity")) {
                expected++;
            }
            else {
                break;
            }
        }   
        int actual = expected;  
        
        for (; 
             expected < expectedChildren.size() && actual < actualChildren.size(); 
             expected++, actual++) {
            Element nextExpected = expectedChildren.get(expected);
            Element nextActual = actualChildren.get(expected);
            // need to normalize characters and ignorable 
            if (nextExpected.getLocalName().equals("ignorable")) {
                if (
                 (nextActual.getLocalName().equals("char") || nextActual.getLocalName().equals("ignorable"))
                  && nextActual.getValue().equals(nextExpected.getValue())) {
                    continue;
                }
                else {
                    return false;
                }
            }
            
            try {
                XOMTestCase.assertEquals(nextExpected, nextActual);
            }
            catch (AssertionFailedError error) {
                // is it a fatalError?
                if (nextActual.getLocalName().equals("fatalError")) {
                    Element expectedPenultimate = expectedChildren.get(expectedChildren.size()-2); 
                    if ("fatalError".equals(expectedPenultimate.getLocalName())) {
                        return true;
                    }
                }
            
                return false;
            }
            
        }
        
        if (expectedChildren.size() != actualChildren.size()) {
            
            return isDoubleFatality(expectedChildren, actualChildren);
            /* if (
               ("fatalError".equals(actualChildren.get(actualSize-2).getQualifiedName())
               || "fatalError".equals(actualChildren.get(actualSize-1).getQualifiedName()))
              && "fatalError".equals(expectedChildren.get(expectedSize-2).getQualifiedName())) {
                return true;
            }
            else {
                return false;
            } */
        }
        
        return true;
        
    }
    
    
    private boolean isDoubleFatality(Elements expected, Elements actual) {
        
        try {
            boolean b1 = expected.get(expected.size()-2).getQualifiedName().equals("fatalError");
            boolean b2 = actual.get(actual.size()-1).getQualifiedName().equals("fatalError")
                       || actual.get(actual.size()-2).getQualifiedName().equals("fatalError");
            return b1 && b2;
        }
        catch (IndexOutOfBoundsException ex) {
            return false;
        }
    
    } 
    

    private boolean containsNotation(Elements expectedNotations, Element actual) {
        
        for (int i = 0; i < expectedNotations.size(); i++) {
            if (compareByValue(expectedNotations.get(i).getFirstChildElement("name"),
               actual.getFirstChildElement("name"))) {
                if (compareByValue(expectedNotations.get(i).getFirstChildElement("publicID"),
                  actual.getFirstChildElement("publicID"))) {
                    Element systemExpected = expectedNotations.get(i).getFirstChildElement("systemID");
                    Element systemActual = actual.getFirstChildElement("systemID");
                    if (systemExpected == systemActual) return true;
                    else if (systemExpected == null || systemActual == null) return false;
                    String expectedSystemID = systemExpected.getValue();
                    String actualSystemID = systemActual.getValue();
                    // change triple slash to single or vice versa????
                    if (expectedSystemID.equals(actualSystemID)) return true;
                    try {
                        String relPart = expectedSystemID.substring(expectedSystemID.indexOf("/expected"));
                        if (systemActual.getValue().endsWith(relPart)) return true;
                    }
                    catch (StringIndexOutOfBoundsException ex) {
                        // no match here; do nothing????
                    }
                }
            }
        }
        
        return false;
    }
    
    
    private boolean containsEntity(Elements expectedEntities, Element actual) {
        
        for (int i = 0; i < expectedEntities.size(); i++) {
            if (compareByValue(expectedEntities.get(i).getFirstChildElement("name"),
               actual.getFirstChildElement("name"))) {
                if (compareByValue(expectedEntities.get(i).getFirstChildElement("publicID"),
                  actual.getFirstChildElement("publicID"))) {
                    Element systemExpected = expectedEntities.get(i).getFirstChildElement("systemID");
                    Element systemActual = actual.getFirstChildElement("systemID");
                    if (systemActual == null) return false;
                    String expectedSystemID = systemExpected.getValue();
                    String relPart = expectedSystemID.substring(expectedSystemID.indexOf("/expected")+"/expected".length());
                    if (systemActual.getValue().endsWith(relPart)) {
                        if (compareByValue(expectedEntities.get(i).getFirstChildElement("notation"),
                          actual.getFirstChildElement("notation"))) {
                            return true;
                        }
                    }
                }
            }
        }
        
        return false;
        
    }
    
    
    private boolean compareByValue(Element e1, Element e2) {
        
        if (e1 == e2) return true;
        else if (e1 == null && e2 != null || e2 == null && e1 != null) return false;
        else return e1.getValue().equals(e2.getValue());
        
    }


    private Document compareResults() 
      throws URISyntaxException, ParsingException, IOException {
      
        Builder builder = new Builder(new XMLBaseFilter());
        File masterList = new File("xmlconf/xmlconf.xml");
        Element root = new Element("TestResults");
        Element parserElement = new Element("Parser");
        parserElement.appendChild(parser);
        root.appendChild(parserElement);
                
        if (masterList.exists()) {
            Document xmlconf = builder.build(masterList);
            Elements testcases = xmlconf.getRootElement().getChildElements("TESTCASES");
            Nodes results = processTestCases(testcases);
            for (int i = 0; i < results.size(); i++) {
                root.appendChild(results.get(i));
            }
        }
        else {
            System.err.println("Could not load conformance suite");
        }
        
        root.addAttribute(new Attribute("testsRun", "" + testsRun));
        root.addAttribute(new Attribute("testsPassed", "" + testsPassed));
        return new Document(root); 

    }

    
    private Nodes processTestCases(Elements testcases) 
      throws URISyntaxException, ParsingException, IOException {

        Nodes result = new Nodes();
        
        for (int i = 0; i < testcases.size(); i++) {
              Element testcase = testcases.get(i); 
              Elements tests = testcase.getChildElements("TEST");
              Nodes results = processTests(tests);
              for (int j = 0; j < results.size(); j++) {
                  result.append(results.get(j));
              }
              Elements level2 = testcase.getChildElements("TESTCASES");
              // need to be recursive to handle recursive IBM test cases
              results = processTestCases(level2);
              for (int j = 0; j < results.size(); j++) {
                  result.append(results.get(j));
              }
        }

        return result;
        
    }


    private Nodes processTests(Elements tests) 
      throws URISyntaxException, ParsingException, IOException  {
        
        boolean wellformed = true;
        
        Nodes results = new Nodes();
        
        Builder builder = new Builder();
        for (int i = 0; i < tests.size(); i++) {
            Element test = tests.get(i);
            String uri = test.getAttributeValue("URI");
            String id = test.getAttributeValue("ID");
            String type = test.getAttributeValue("TYPE");
            
            String base = test.getBaseURI();
            String message = test.getValue();
            URI baseURI= new URI(base);
            URI testURI = baseURI.resolve(uri);
            String original = testURI.toString();
            int position = original.lastIndexOf("/xmlconf/");
            String actual = original.substring(0, position) 
              + "/results/" + parser + "/" + original.substring(position+9);
            String expected = original.substring(0, position) 
              + "/expected/" + original.substring(position+9);
            boolean testPassed = compare(expected, actual);
            
            Element testResult = new Element("TestResult");
            testResult.addAttribute(new Attribute("original", original));
            testResult.addAttribute(new Attribute("expected", expected));
            testResult.addAttribute(new Attribute("actual", actual));
            testResult.appendChild(message);
            testResult.addAttribute(new Attribute("passed", Boolean.toString(testPassed)));
            testResult.addAttribute(new Attribute(test.getAttribute("TYPE")));
            testResult.addAttribute(new Attribute(test.getAttribute("ID")));
            testResult.addAttribute(new Attribute(test.getAttribute("SECTIONS")));
            results.append(testResult);
            
            makeResultDoc(original, expected, actual, message, id, testPassed);       
            
        }
        
        return results;
        
    }
    
    
    private void makeResultDoc(String original, String expected, String actual,
            String message, String id, boolean passed) {
        
        String outputFileName = actual.substring(5) + ".html";
        String title = "Test case " + id + ": " + parser;
        if (passed) title += " Passed";
        else title += " Failed";
        Element root = new Element("html");
        Document doc = new Document(root);
        Element body = new Element("body");
        root.appendChild(body);
        Element h1 = new Element("h1");
        h1.appendChild(title);
        body.appendChild(h1);
        
        Element head = new Element("head");
        body.appendChild(head);
        Element titleElement = new Element(h1);
        titleElement.setLocalName("title");
        head.appendChild(titleElement);
        
        
        Element p = new Element("p");
        p.appendChild(message);
        body.appendChild(p);
        
        Element pre = new Element("pre");
        body.appendChild(pre);
        Element loadOriginal = new Element("xi:include", XIncluder.XINCLUDE_NS);
        loadOriginal.addAttribute(new Attribute("parse", "text"));
        loadOriginal.addAttribute(new Attribute("href", original));
        pre.appendChild(loadOriginal);
        
        Element table = new Element("table");
        table.addAttribute(new Attribute("border", "1"));
        body.appendChild(table);
        Element header = new Element("tr");
        table.appendChild(header);
        Element col1 = new Element("th");
        Element col2 = new Element("th");
        header.appendChild(col1);
        header.appendChild(col2);
        col1.appendChild("Expected result");
        col2.appendChild("Actual result for " + parser);
        
        Element tr = new Element("tr");
        table.appendChild(tr);
        
        Element preExpected = new Element("pre");
        Element expectedTD = new Element("td");
        expectedTD.addAttribute(new Attribute("valign", "top"));
        expectedTD.appendChild(preExpected);
        Element loadExpected = new Element("xi:include", XIncluder.XINCLUDE_NS);
        loadExpected.addAttribute(new Attribute("parse", "text"));
        loadExpected.addAttribute(new Attribute("href", expected));
        preExpected.appendChild(loadExpected);
        tr.appendChild(expectedTD);
        
        Element preActual = new Element("pre");
        Element actualTD = new Element("td");
        actualTD.appendChild(preActual);
        actualTD.addAttribute(new Attribute("valign", "top"));
        Element loadActual = new Element("xi:include", XIncluder.XINCLUDE_NS);
        loadActual.addAttribute(new Attribute("parse", "text"));
        loadActual.addAttribute(new Attribute("href", actual));
        preActual.appendChild(loadActual);
        tr.appendChild(actualTD);
        
        Element ul = new Element("ul");
        body.appendChild(ul);
        
        for (int i = 0; i < ConformanceGenerator.parsers.length; i++) {
            Element a = new Element("a");
            String relative = outputFileName.replaceFirst(parser, ConformanceGenerator.parsers[i]);
            a.addAttribute(new Attribute("href", relative));
            a.appendChild("View results in " + ConformanceGenerator.parsers[i]);
            Element li = new Element("li");
            li.appendChild(a);
            ul.appendChild(li);
        }
        
        body.appendChild(new Element("hr"));
        /*Element back = new Element("p");
        Element a = new Element("a");
        a.appendChild("Back to results for " + parser);
        a.addAttribute(new Attribute("href", ""));
        body.appendChild(back); */
        
        try {
            XIncluder.resolveInPlace(doc);
        } 
        catch (Exception ex) {
            Element sub = new Element("p");
            sub.appendChild("The original document is too malformed to include but you can find it ");
            Element a = new Element("a");
            sub.appendChild(a);
            a.appendChild("here.");
            a.addAttribute(new Attribute("href", original));
            
            body.insertChild(sub, 1);
            body.removeChild(pre);
            try {
                XIncluder.resolveInPlace(doc);
            } 
            catch (Exception ex2) {
                System.err.println(ex2);
                return;
            }
        } 
        
        
        OutputStream out = null;
        try {
            out = new BufferedOutputStream(new FileOutputStream(outputFileName));
            Serializer serializer = new Serializer(out);
            serializer.write(doc);
            serializer.flush();
        }
        catch (IOException ex) {
            System.err.println(ex);
        }
        finally {
            if (out != null) {
                try {
                    out.close();
                } 
                catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        
    }


    // The test suite uses incorrect xml:base attributes that need to be removed
    private static class XMLBaseFilter extends NodeFactory {
        
        private Nodes empty = new Nodes();
        
        public Nodes makeAttribute(String name, String URI, String value, Attribute.Type type) {
            if ("xml:base".equals(name)) return empty;
            else return super.makeAttribute(name, URI, value, type);
        }
        
    }
    
    
}
